package com.paparazziapps.pretamistapp.data.network

data class GeneralResponse (
    val code:Int,
    val message:String
)