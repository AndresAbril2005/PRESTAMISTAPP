package com.paparazziapps.pretamistapp.frameworks.network

object ResendConstants {

    const val BASE_URL = "https://api.resend.com/"

    //Endpoints

    const val EMAILS = "emails"
}