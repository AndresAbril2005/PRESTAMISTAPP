package com.paparazziapps.pretamistapp.application

object PASConstantsPreferences {

    const val LOAN_PREFERENCES_COMMON = "loan_preferences_common"
}