package com.paparazziapps.pretamistapp.domain.notification

data class EmailReceiptResponse(
    val id: String?= null
)