package com.paparazziapps.pretamistapp.helper



const val INT_DEFAULT   = -27805
const val SHORT_ANIMATION_DURATION = 150L