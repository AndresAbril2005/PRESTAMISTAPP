package com.paparazziapps.pretamistapp.domain

data class DetailLoanDomain(
    val idLoan:String,
    val totalAmountToPay:Double,
)