package com.paparazziapps.pretamistapp.domain

object PAConstants {

    //Extras
    const val EXTRA_LOAN_JSON = "extra_user"
    const val EXTRA_CLIENT_JSON = "extra_client"
    const val INFORMATION_RECEIPT = "information_receipt"
}